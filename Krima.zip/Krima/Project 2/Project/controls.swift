
import UIKit
import SkyFloatingLabelTextField
import SSBouncyButton

class controls: NSObject
{
    func textfield(frm:CGRect,placeholder:String,title:String,tintcolor:UIColor?,selectedtitlecolor:UIColor?,linecolor:UIColor?,icontype:IconType,iconimage:UIImage,iconcolor:UIColor?) -> SkyFloatingLabelTextFieldWithIcon
    {
        let txt = SkyFloatingLabelTextFieldWithIcon(frame: frm)
        txt.placeholder = placeholder
        txt.title = title
        txt.tintColor = tintcolor
        txt.selectedTitleColor = selectedtitlecolor!
        txt.lineColor = linecolor!
        txt.iconType = icontype
        txt.iconColor = iconcolor!
        txt.iconImage = iconimage
        return txt
    }
    
    func button(frm:CGRect,title:String,tintcolor:UIColor?,cornerradious:CGFloat?,bgcolor:UIColor?) -> SSBouncyButton
    {
        let reg = SSBouncyButton(frame:frm)
        reg.cornerRadius = cornerradious!
        reg.setTitle(title, for: .normal)
        reg.tintColor = tintcolor
        reg.backgroundColor = bgcolor
        reg.setTitle(title, for: .normal)
        return reg

    }
}


