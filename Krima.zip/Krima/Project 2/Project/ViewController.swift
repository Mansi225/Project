
import UIKit
import SkyFloatingLabelTextField
import SSBouncyButton

class ViewController: UIViewController,UINavigationControllerDelegate
{
    let con = controls()
    var name = SkyFloatingLabelTextFieldWithIcon()
    var mno = SkyFloatingLabelTextFieldWithIcon()
    var email = SkyFloatingLabelTextFieldWithIcon()
    var pass = SkyFloatingLabelTextFieldWithIcon()
    var cpass = SkyFloatingLabelTextFieldWithIcon()
    var reg = SSBouncyButton()
    var reset = SSBouncyButton()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        Addtxt()
    }

    func Addtxt()
    {
        name = con.textfield(frm: CGRect(x: 50, y: 150, width: 200, height: 45), placeholder: "Name", title: "User name", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "username.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(name)
      
        mno = con.textfield(frm: CGRect(x: 50, y: 225, width: 200, height: 45), placeholder: "Mobile No.", title: "Enter your mobile No.", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "mobile.jpeg"), iconcolor: UIColor.cyan)
        self.view.addSubview(mno)
        
        email = con.textfield(frm: CGRect(x: 50, y: 300, width: 200, height: 45), placeholder: "Email-ID", title: "Enter your email id", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "email.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(email)
        
        pass = con.textfield(frm: CGRect(x: 50, y: 375, width: 200, height: 45), placeholder: "Password", title: "Enter password", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "password.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(pass)
        
        cpass = con.textfield(frm: CGRect(x: 50, y: 450, width: 200, height: 45), placeholder: "Confirm Password", title: "Same as password", tintcolor: UIColor.gray, selectedtitlecolor: UIColor.cyan, linecolor: UIColor.cyan, icontype: .image, iconimage: UIImage(imageLiteralResourceName: "cpass.png"), iconcolor: UIColor.cyan)
        self.view.addSubview(cpass)
        
       reg = con.button(frm: CGRect(x: 70, y: 550, width: 100, height: 30), title: "Register", tintcolor: UIColor.black, cornerradious: 5, bgcolor: UIColor.gray)
        reg.addTarget(self, action: #selector(self.register), for: .touchUpInside)
        self.view.addSubview(reg)
        
        reset = con.button(frm: CGRect(x: 200, y: 550, width: 100, height: 30), title: "Reset", tintcolor: UIColor.black, cornerradious: 5, bgcolor: UIColor.gray)
        reset.addTarget(self, action: #selector(self.resetbutton), for: .touchUpInside)
        self.view.addSubview(reset)

    }
    func resetbutton(sender:SSBouncyButton)
    {
        name.text = ""
        email.text = ""
        mno.text = ""
        pass.text = ""
        cpass.text = ""
    }
    func register(sender:SSBouncyButton)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    @IBAction func login(_ sender: Any)
    {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }


}

